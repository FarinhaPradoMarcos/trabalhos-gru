const storedSalt = localStorage.getItem("salt") || CryptoJS.lib.WordArray.random(128 / 8).toString(); // Gera um salt aleatório ou carrega do LocalStorage
localStorage.setItem("salt", storedSalt);

const iterations = 1000; // Número de iterações do PBKDF2

let encryptedPasswords = JSON.parse(localStorage.getItem("passwords")) || [];

// Função para derivar uma chave usando PBKDF2
function deriveKey(password) {
    return CryptoJS.PBKDF2(password, storedSalt, {
        keySize: 256 / 32,
        iterations: iterations
    });
}

// Função para desbloquear o cofre
function unlockVault() {
    const inputPassword = document.getElementById("master-password").value;
    const derivedKey = deriveKey(inputPassword);

    // Testa descriptografar a primeira senha para verificar se a chave é válida
    if (encryptedPasswords.length > 0) {
        try {
            const decryptedTestPassword = CryptoJS.AES.decrypt(encryptedPasswords[0].encryptedPassword, derivedKey).toString(CryptoJS.enc.Utf8);
            if (decryptedTestPassword === "") throw new Error("Senha incorreta");
        } catch (e) {
            alert("Senha mestre incorreta!");
            return;
        }
    }

    document.getElementById("login-section").style.display = 'none';
    document.getElementById("vault-section").style.display = 'block';
    displayPasswords(derivedKey);
}

// Função para adicionar uma nova senha ao cofre
function addPassword() {
    const serviceName = document.getElementById("service-name").value;
    const servicePassword = document.getElementById("service-password").value;

    if (serviceName && servicePassword) {
        const derivedKey = deriveKey(document.getElementById("master-password").value);
        const encryptedPassword = CryptoJS.AES.encrypt(servicePassword, derivedKey).toString();
        encryptedPasswords.push({ serviceName, encryptedPassword });
        
        // Atualiza o LocalStorage com as novas senhas
        localStorage.setItem("passwords", JSON.stringify(encryptedPasswords));
        
        displayPasswords(derivedKey);
    } else {
        alert("Por favor, preencha todos os campos.");
    }
}

// Função para mostrar as senhas armazenadas
function displayPasswords(derivedKey) {
    const passwordList = document.getElementById("password-list");
    passwordList.innerHTML = '';

    encryptedPasswords.forEach((item, index) => {
        try {
            const decryptedPassword = CryptoJS.AES.decrypt(item.encryptedPassword, derivedKey).toString(CryptoJS.enc.Utf8);
            const li = document.createElement("li");
            li.textContent = `${item.serviceName}: ${decryptedPassword}`;
            passwordList.appendChild(li);
        } catch (e) {
            console.error("Erro ao descriptografar senha:", e);
        }
    });
}

// Ao carregar a página, exibe as senhas se a senha mestre estiver correta
window.onload = function() {
    if (encryptedPasswords.length > 0) {
        document.getElementById("master-password").focus();
    }
}
