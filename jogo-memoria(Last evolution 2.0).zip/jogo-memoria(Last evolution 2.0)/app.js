document.addEventListener('DOMContentLoaded', () => {
  //listar todas as cartas q existem
  const cardArray = [
    {
      name: 'berserk',
      img: 'images/berserk.png'
    },
    {
      name: 'dbz',
      img: 'images/dragon.png'
    },
    {
      name: 'digi',
      img: 'images/digi.png'
    },
    {
      name: 'poke',
      img: 'images/poke.png'
    },
    {
      name: 'geass',
      img: 'images/code.png'
    },
    {
      name: 'eva',
      img: 'images/eva.png'
    },
    {
      name: 'jojo',
      img: 'images/jojo.png'
    },
    {
      name: 'naruto',
      img: 'images/naruto.png'
    },
  ]

  let moves = 0 // initialize move counter
  const movesDisplay = document.querySelector('#moves') // mostra os movimentos feitos
  let flipCount = 0 // initialize flip count

  const cardArray48 = [ ...cardArray, ...cardArray, ...cardArray, ...cardArray]; // gambiarra pra aparecer varias cartas do mesmo tipo duplicando as arrays

  const grid = document.querySelector('.grid')
  const resultDisplay = document.querySelector('#result')
  const timerDisplay = document.querySelector('#timer') // mostra o timer
  let cardsChosen = []
  let cardsChosenId = []//espaço vazio pra guardar cartas que foram escolhidas
  let cardsWon = [] //espaço vazio pra guardar cartas que foram juntadas
  let startTime = 0 // start time of the game
  let timerInterval = null // interval for updating the timer

  //create your board
  function createBoard() {
    // Shuffle the card array
    for (let i = cardArray48.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [cardArray48[i], cardArray48[j]] = [cardArray48[j], cardArray48[i]];
    }
  
    for (let i = 0; i < cardArray48.length; i++) {
      const card = document.createElement('img')
      card.setAttribute('src', 'images/fundo.png')
      card.setAttribute('data-id', i)
      card.addEventListener('click', flipCard)
      grid.appendChild(card)
    }
    startTime = new Date().getTime() // inicia o timer
    timerInterval = setInterval(updateTimer, 1000) // atualiza o timer a cada 1000 milesimos(1seg)
  }

  //check for matches
  function checkForMatch() {
    const cards = document.querySelectorAll('img')
    const optionOneId = cardsChosenId[0]
    const optionTwoId = cardsChosenId[1]
    
    if(optionOneId == optionTwoId) {
      cards[optionOneId].setAttribute('src', 'images/fundo.png') //imagem que fica atras na carta
      cards[optionTwoId].setAttribute('src', 'images/fundo.png') //imagem que fica atras na carta
      alert('Você clicou na mesma imagem duas vezes, tente novamente!')
    }
    else if (cardsChosen[0] === cardsChosen[1]) {
      alert('You found a match')
      cards[optionOneId].setAttribute('src', 'images/gamb.png') //carta virada ira ter essa imagem
      cards[optionTwoId].setAttribute('src', 'images/gamb.png')  //carta virada 2 ira ter essa imagem
      cards[optionOneId].removeEventListener('click', flipCard)
      cards[optionTwoId].removeEventListener('click', flipCard)
      cardsWon.push(cardsChosen)
    } else {
      cards[optionOneId].setAttribute('src', 'images/fundo.png')
      cards[optionTwoId].setAttribute('src', 'images/fundo.png')
      alert('Você errou')
    }
    cardsChosen = []
    cardsChosenId = []
    resultDisplay.textContent = cardsWon.length
    if  (cardsWon.length === cardArray48.length/2) {
      resultDisplay.textContent = 'Parabéns você é o mestre do Jogo da memória!'
      clearInterval(timerInterval) // para o timer dps da vitória 
      timerDisplay.textContent = `Time: ${formatTime(elapsedTime())}` // mostra o tempo final
    }
  }

  //flip your card
  function flipCard() {
    let cardId = this.getAttribute('data-id')
    cardsChosen.push(cardArray48[cardId].name)
    cardsChosenId.push(cardId)
    this.setAttribute('src', cardArray48[cardId].img)
    flipCount++ // increment flip count
    if (flipCount === 2) {
      moves++ // aumenta o contador de movimentos quando duas cartas são viradas
      movesDisplay.textContent = `: ${moves}` // mostra o tanto de movimentos feito
      flipCount = 0 // reset flip count
    }
    if (cardsChosen.length === 2) {
      setTimeout(checkForMatch, 500)
    }
  }

  function updateTimer() { //update do tempo
    const currentTime = new Date().getTime()
    const elapsedTime = currentTime - startTime
    timerDisplay.textContent = `: ${formatTime(elapsedTime)}`
  }

  function formatTime(time) { //formatação do tempo q vai aparecer no HTML
    const minutes = Math.floor(time / 60000)
    const seconds = Math.floor((time % 60000) / 1000)
    return `${minutes} minutos e ${seconds} segundos`
  }

document.getElementById("music-switch").addEventListener("change", function() {
  if (this.checked) {
    document.getElementById("background-music").play();
  } else {
    document.getElementById("background-music").pause();
  }
  });
  createBoard()
})