let canvas = document.getElementById("gameCanvas");
let ctx = canvas.getContext("2d");

let nave = {
    x: canvas.width / 2 - 15,
    y: canvas.height / 2 - 15,
    width: 30,
    height: 30,
    dx: 0,
    dy: 0,
    velocidade: 3,
    boost: false  // Boost de velocidade
};

let oxigenio = 100;
let vidas = 3;
let oxigenioBoost = 50;  // Quanto o tanque de oxigênio recupera
let intervalId;
let oxigenioLabel = document.getElementById("oxigenioLabel");
let vidaLabel = document.getElementById("vidaLabel");
let mensagem = document.getElementById("mensagem");

let currentLevel = 0;
let tanquesDeOxigenio = [];
let tempoParaOxigenio = 8000;  // Intervalo para gerar tanques de oxigênio
let oxigenioTaxaNormal = 0.5;  // Redução normal de oxigênio (Decreased)
let oxigenioTaxaBoost = 1.5;   // Redução de oxigênio durante boost (Decreased)

let salas = [
    {
        portas: [{ x: 600, y: 100, width: 40, height: 100, aberta: false }],
        cabos: [{ x: 200, y: 150, width: 100, height: 20, ativado: false }],
        bombas: [{ x: 350, y: 300, width: 7.5, height: 7.5, dx: 2, dy: 2 }]  // Bombas 1/4 do tamanho da nave
    },
    {
        portas: [{ x: 500, y: 200, width: 50, height: 100, aberta: false }],
        cabos: [{ x: 300, y: 200, width: 100, height: 20, ativado: false }, { x: 400, y: 300, width: 100, height: 20, ativado: false }],
        bombas: [{ x: 150, y: 150, width: 7.5, height: 7.5, dx: -1, dy: 1 }]  // Bombas 1/4 do tamanho da nave
    }
];

let lasers = [
    { x: 100, y: 50, width: 50, height: 1.25, speed: 5, direction: 1 },  // Lasers 1/4 do tamanho da nave
    { x: 200, y: 400, width: 50, height: 1.25, speed: 3, direction: 1 }  // Lasers 1/4 do tamanho da nave
];

let asteroides = [];  // Lista para os asteroides

// Função para gerar tanques de oxigênio
function gerarTanqueDeOxigenio() {
    tanquesDeOxigenio.push({
        x: Math.random() * (canvas.width - 20),
        y: Math.random() * (canvas.height - 20),
        width: 15,
        height: 15
    });
}

// Função para desenhar tanques de oxigênio
function desenharTanquesDeOxigenio() {
    tanquesDeOxigenio.forEach(tanque => {
        ctx.fillStyle = "lightblue";
        ctx.fillRect(tanque.x, tanque.y, tanque.width, tanque.height);
    });
}

// Função para verificar se a nave coleta um tanque de oxigênio
function coletarTanqueDeOxigenio() {
    tanquesDeOxigenio.forEach((tanque, index) => {
        if (nave.x < tanque.x + tanque.width && nave.x + nave.width > tanque.x &&
            nave.y < tanque.y + tanque.height && nave.y + nave.height > tanque.y) {
            oxigenio = Math.min(100, oxigenio + oxigenioBoost);  // Adiciona 50% do oxigênio, sem passar de 100%
            tanquesDeOxigenio.splice(index, 1);  // Remove o tanque após ser coletado
            mensagem.innerHTML = "Tanque de oxigênio coletado!";
        }
    });
}

// Função para gerar asteroides
function gerarAsteroides() {
    asteroides.push({ x: canvas.width, y: Math.random() * canvas.height, width: 7.5, height: 7.5, speed: Math.random() * 3 + 2 });  // Asteroides 1/4 do tamanho da nave
}

// Função para desenhar asteroides
function desenharAsteroides() {
    asteroides.forEach(asteroide => {
        ctx.fillStyle = "gray";
        ctx.fillRect(asteroide.x, asteroide.y, asteroide.width, asteroide.height);

        // Movimento do asteroide da direita para a esquerda
        asteroide.x -= asteroide.speed;

        // Remover asteroides que saíram da tela
        if (asteroide.x + asteroide.width < 0) {
            asteroides.splice(asteroides.indexOf(asteroide), 1);
        }
    });
}

// Função para desenhar a nave
function desenharNave() {
    ctx.fillStyle = "#00f";
    ctx.fillRect(nave.x, nave.y, nave.width, nave.height);
}

// Função para desenhar bombas e movê-las
function desenharBombas() {
    let sala = salas[currentLevel];
    sala.bombas.forEach(bomba => {
        ctx.fillStyle = "orange";
        ctx.fillRect(bomba.x, bomba.y, bomba.width, bomba.height);

        // Movimento das bombas
        bomba.x += bomba.dx;
        bomba.y += bomba.dy;

        // Verificar se atingiu os limites da tela
        if (bomba.x <= 0 || bomba.x + bomba.width >= canvas.width) bomba.dx *= -1;
        if (bomba.y <= 0 || bomba.y + bomba.height >= canvas.height) bomba.dy *= -1;
    });
}

// Função para ativar cabos de energia
function ativarCabos() {
    let sala = salas[currentLevel];
    sala.cabos.forEach(cabo => {
        if (!cabo.ativado && nave.x < cabo.x + cabo.width && nave.x + nave.width > cabo.x &&
            nave.y < cabo.y + cabo.height && nave.y + cabo.height > cabo.y) {
            cabo.ativado = true;
            mensagem.innerHTML = "Cabo de energia ativado!";
        }
    });
}

// Função para reduzir o oxigênio
function reduzirOxigenio() {
    let taxa = nave.boost ? oxigenioTaxaBoost : oxigenioTaxaNormal;  // Usa taxa maior se o boost estiver ativo
    oxigenio -= taxa;
    oxigenioLabel.innerHTML = `Oxigênio: ${oxigenio}%`;

    if (oxigenio <= 0) {
        mensagem.innerHTML = "Você ficou sem oxigênio! Fim de jogo!";
        clearInterval(intervalId);
    }
}

// Função para desenhar todos os elementos
function desenhar() {
    limparCanvas();
    desenharNave();
    desenharBombas();  // Desenhar as bombas
    desenharTanquesDeOxigenio();  // Desenhar tanques de oxigênio
    desenharAsteroides();  // Desenhar os asteroides
    ativarCabos();
    coletarTanqueDeOxigenio();
}

// Função para atualizar o jogo a cada frame
function atualizarJogo() {
    moverNave();
    desenhar();
}

// Função para mover a nave
function moverNave() {
    nave.x += nave.dx;
    nave.y += nave.dy;

    if (nave.x < 0) nave.x = 0;
    if (nave.x + nave.width > canvas.width) nave.x = canvas.width - nave.width;
    if (nave.y < 0) nave.y = 0;
    if (nave.y + nave.height > canvas.height) nave.y = canvas.height - nave.height;
}

// Controle de teclado
document.addEventListener("keydown", (e) => {
    if (e.key === "ArrowRight" || e.key === "d") nave.dx = nave.boost ? nave.velocidade * 2 : nave.velocidade;
    if (e.key === "ArrowLeft" || e.key === "a") nave.dx = nave.boost ? -nave.velocidade * 2 : -nave.velocidade;
    if (e.key === "ArrowUp" || e.key === "w") nave.dy = nave.boost ? -nave.velocidade * 2 : -nave.velocidade;
    if (e.key === "ArrowDown" || e.key === "s") nave.dy = nave.boost ? nave.velocidade * 2 : nave.velocidade;
    if (e.key === " ") nave.boost = true;  // Ativa o boost quando "espaço" é pressionado
});

document.addEventListener("keyup", (e) => {
    if (e.key === "ArrowRight" || e.key === "d") nave.dx = 0;
    if (e.key === "ArrowLeft" || e.key === "a") nave.dx = 0;
    if (e.key === "ArrowUp" || e.key === "w") nave.dy = 0;
    if (e.key === "ArrowDown" || e.key === "s") nave.dy = 0;
    if (e.key === " ") nave.boost = false;  // Desativa o boost quando "espaço" é solto
});

// Função para limpar o canvas
function limparCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}

// Iniciar Jogo
document.getElementById("startBtn").addEventListener("click", () => {
    oxigenio = 100;
    vidas = 3;
    mensagem.innerHTML = "";
    oxigenioLabel.innerHTML = `Oxigênio: ${oxigenio}%`;
    vidaLabel.innerHTML = `Vidas: ${vidas}`;
    clearInterval(intervalId);

    // Gerar asteroides e tanques de oxigênio periodicamente
    setInterval(gerarAsteroides, 2000);
    setInterval(gerarTanqueDeOxigenio, tempoParaOxigenio);

    intervalId = setInterval(() => {
        atualizarJogo();
        reduzirOxigenio();
    }, 100);
});
// ... (previous code)

let corpos = [];  // Array para os corpos
let corposResgatados = 0;  // Contador de corpos resgatados

// Função para gerar corpos
function gerarCorpos() {
    corpos.push({
        x: Math.random() * (canvas.width - 20),
        y: Math.random() * (canvas.height - 20),
        width: 15,
        height: 15,
        rescued: false
    });
}

// Função para desenhar corpos
function desenharCorpos() {
    corpos.forEach(corpo => {
        if (!corpo.rescued) {
            ctx.fillStyle = "yellow";
            ctx.fillRect(corpo.x, corpo.y, corpo.width, corpo.height);
        }
    });
}

// Função para verificar se a nave coletou um corpo
function coletarCorpo() {
    corpos.forEach((corpo, index) => {
        if (nave.x < corpo.x + corpo.width && nave.x + nave.width > corpo.x &&
            nave.y < corpo.y + corpo.height && nave.y + nave.height > corpo.y && !corpo.rescued) {
            corpo.rescued = true;  // Marca o corpo como resgatado
            corposResgatados++;  // Incrementa o contador
            mensagem.innerHTML = "Corpo resgatado!";
        }
    });
}

// Função para verificar colisão com asteroides
function verificarColisaoAsteroide() {
    asteroides.forEach(asteroide => {
        // Check if the ship is within the safe area
        if (nave.x >= canvas.width/4 && nave.x <= 3*canvas.width/4 && 
            nave.y >= canvas.height/4 && nave.y <= 3*canvas.height/4) {
            return; // Skip collision check if within safe area
        }

        if (nave.x < asteroide.x + asteroide.width && nave.x + nave.width > asteroide.x &&
            nave.y < asteroide.y + asteroide.height && nave.y + nave.height > asteroide.y) {
            vidas--;
            vidaLabel.innerHTML = `Vidas: ${vidas}`;
            mensagem.innerHTML = "Você colidiu com um asteroide!";
            if (vidas === 0) {
                mensagem.innerHTML = "Você perdeu todas as vidas! Fim de jogo!";
                clearInterval(intervalId);
            }
        }
    });
}

// Função para atualizar o jogo a cada frame
function atualizarJogo() {
    moverNave();
    desenhar();
    coletarTanqueDeOxigenio();
    coletarCorpo();
    verificarColisaoAsteroide();
}

// Iniciar Jogo
document.getElementById("startBtn").addEventListener("click", () => {
    // ... (previous code)

    // Gerar corpos periodicamente
    setInterval(gerarCorpos, 3000); // Ajustar o intervalo conforme necessário
    corposResgatados = 0; // Reiniciar o contador

    // ... (rest of the code)
});

// Função para desenhar todos os elementos
function desenhar() {
    limparCanvas();
    desenharNave();
    desenharBombas();
    desenharTanquesDeOxigenio();
    desenharAsteroides();
    desenharCorpos(); // Desenhar os corpos
    ativarCabos();
    coletarTanqueDeOxigenio();

    // Draw safe area (optional)
    ctx.strokeStyle = "green"; 
    ctx.strokeRect(canvas.width/4, canvas.height/4, canvas.width/2, canvas.height/2); // Outline of safe area

    // Verificar se todos os corpos foram resgatados
    if (corposResgatados === 10) { // Changed to 10 rescued bodies
        mensagem.innerHTML = "Parabéns! Você resgatou todos os corpos!";
        clearInterval(intervalId);
    }
}

// ... (rest of the code)
