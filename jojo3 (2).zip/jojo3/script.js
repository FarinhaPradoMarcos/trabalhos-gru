const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
canvas.width = 600;
canvas.height = 600;

let carImage = new Image();
carImage.src = 'images/mc.jpg'; // Substitua pelo caminho correto da imagem do carro

let car = { x: 280, y: 500, width: 40, height: 70, speed: 5 };
let obstacles = [];
let score = 0;
let gameSpeed = 3;
let gameOver = false;
let keys = {};

// Função para desenhar o carro usando uma imagem
function drawCar() {
  ctx.drawImage(carImage, car.x, car.y, car.width, car.height);
}

// Função para criar obstáculos
function createObstacle() {
  let width = Math.random() * 150 + 50;
  let x = Math.random() * (canvas.width - width);
  obstacles.push({ x, y: 0, width, height: 20 });
}

// Função para desenhar obstáculos
function drawObstacles() {
  ctx.fillStyle = 'red';
  obstacles.forEach(obstacle => {
    obstacle.y += gameSpeed;
    ctx.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height);
  });
}

// Função para detectar colisão
function checkCollision() {
  obstacles.forEach(obstacle => {
    if (
      car.x < obstacle.x + obstacle.width &&
      car.x + car.width > obstacle.x &&
      car.y < obstacle.y + obstacle.height &&
      car.height + car.y > obstacle.y
    ) {
      gameOver = true;
    }
  });
}

// Função para atualizar o jogo
function updateGame() {
  if (gameOver) {
    alert(`Game Over! Pontuação final: ${score}`);
    document.location.reload();
  }

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Movimentação fluida do carro
  if (keys['ArrowLeft'] && car.x > 0) car.x -= car.speed;
  if (keys['ArrowRight'] && car.x + car.width < canvas.width) car.x += car.speed;
  if (keys['ArrowUp'] && car.y > 0) car.y -= car.speed;
  if (keys['ArrowDown'] && car.y + car.height < canvas.height) car.y += car.speed;

  // Desenhar carro e obstáculos
  drawCar();
  drawObstacles();
  checkCollision();

  // Aumentar a pontuação e velocidade com o tempo
  score++;
  gameSpeed += 0.002;
  document.getElementById('score').innerText = score;

  // Remover obstáculos fora da tela
  obstacles = obstacles.filter(obstacle => obstacle.y < canvas.height);

  requestAnimationFrame(updateGame);
}

// Controle contínuo do carro
document.addEventListener('keydown', (e) => {
  keys[e.key] = true;
});

document.addEventListener('keyup', (e) => {
  keys[e.key] = false;
});

// Iniciar o jogo
setInterval(createObstacle, 2000);
updateGame();
