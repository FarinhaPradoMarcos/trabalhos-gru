const gameContainer = document.getElementById('gameContainer');
const spaceship = document.getElementById('spaceship');
const scoreDisplay = document.querySelector('.score-display');
const livesDisplay = document.querySelector('.lives-display');

let spaceshipPosition = window.innerWidth / 2 - 25;
let bullets = [];
let enemies = [];
let lives = 3;
let score = 0;
let isGameOver = false;
let enemySpawnRate = 2000;
let moveLeft = false;
let moveRight = false;

// Movimentação da nave
function moveSpaceship() {
    if (moveLeft && spaceshipPosition > 0) {
        spaceshipPosition -= 5;
    }
    if (moveRight && spaceshipPosition < window.innerWidth - 50) {
        spaceshipPosition += 5;
    }
    spaceship.style.left = `${spaceshipPosition}px`;
}

// Atirar projéteis
function shootBullet() {
    const bullet = document.createElement('div');
    bullet.classList.add('bullet');
    bullet.style.left = `${spaceshipPosition + 22}px`;
    bullet.style.bottom = '70px';
    gameContainer.appendChild(bullet);
    bullets.push(bullet);

    const bulletInterval = setInterval(() => {
        let bulletTop = parseInt(bullet.style.bottom);
        bullet.style.bottom = `${bulletTop + 10}px`;

        if (bulletTop >= window.innerHeight) {
            bullet.remove();
            bullets = bullets.filter(b => b !== bullet);
            clearInterval(bulletInterval);
        }

        enemies.forEach((enemy) => {
            if (detectCollision(bullet, enemy)) {
                bullet.remove();
                enemy.remove();
                bullets = bullets.filter(b => b !== bullet);
                enemies = enemies.filter(e => e !== enemy);
                generateExplosion(enemy.style.left, enemy.style.top);
                updateScore();
                clearInterval(bulletInterval);
            }
        });
    }, 20);
}

// Detectar colisões
function detectCollision(obj1, obj2) {
    const rect1 = obj1.getBoundingClientRect();
    const rect2 = obj2.getBoundingClientRect();
    return !(rect1.top > rect2.bottom || rect1.bottom < rect2.top || rect1.left > rect2.right || rect1.right < rect2.left);
}

// Gerar explosão visual
function generateExplosion(x, y) {
    for (let i = 0; i < 10; i++) {
        const particle = document.createElement('div');
        particle.classList.add('particle');
        particle.style.left = x;
        particle.style.top = y;
        gameContainer.appendChild(particle);

        const speedX = (Math.random() - 0.5) * 5;
        const speedY = (Math.random() - 0.5) * 5;
        const particleInterval = setInterval(() => {
            let particleX = parseFloat(particle.style.left);
            let particleY = parseFloat(particle.style.top);
            particle.style.left = `${particleX + speedX}px`;
            particle.style.top = `${particleY + speedY}px`;

            if (particleY > window.innerHeight || particleX < 0 || particleX > window.innerWidth) {
                particle.remove();
                clearInterval(particleInterval);
            }
        }, 20);
    }
}

// Atualizar a pontuação
function updateScore() {
    score += 10;
    scoreDisplay.textContent = `Score: ${score}`;
}

// Função para gerar inimigos
function generateEnemy() {
    const enemy = document.createElement('div');
    enemy.classList.add('enemy');
    enemy.style.left = `${Math.random() * (window.innerWidth - 50)}px`;
    enemy.style.top = '0px';
    gameContainer.appendChild(enemy);
    enemies.push(enemy);

    const enemyInterval = setInterval(() => {
        let enemyTop = parseInt(enemy.style.top);
        enemy.style.top = `${enemyTop + 2}px`;

        if (enemyTop >= window.innerHeight - 50) {
            clearInterval(enemyInterval);
            enemy.remove();
            loseLife();
        }
    }, 20);
}

// Função para perder vida
function loseLife() {
    lives--;
    livesDisplay.textContent = `Vidas: ${lives}`;
    if (lives === 0) {
        endGame();
    }
}


// Função principal para iniciar o jogo
function startGame() {
    setInterval(moveSpaceship, 20);
    setInterval(() => {
        if (!isGameOver) {
            generateEnemy();
        }
    }, enemySpawnRate);
}

startGame();

// Controles da nave
document.addEventListener('keydown', (e) => {
    if (e.code === 'ArrowLeft') moveLeft = true;
    if (e.code === 'ArrowRight') moveRight = true;
    if (e.code === 'Space') shootBullet();
});

document.addEventListener('keyup', (e) => {
    if (e.code === 'ArrowLeft') moveLeft = false;
    if (e.code === 'ArrowRight') moveRight = false;
});
