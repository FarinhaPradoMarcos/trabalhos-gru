const forge = require("node-forge");

// Gera o par de chaves RSA
const { privateKey, publicKey } = forge.pki.rsa.generateKeyPair(2048);

// Serializa a chave privada em formato PEM
const privateKeyPem = forge.pki.privateKeyToPem(privateKey);
console.log("Chave Privada (PEM):\n", privateKeyPem);

// Serializa a chave pública em formato PEM
const publicKeyPem = forge.pki.publicKeyToPem(publicKey);
console.log("Chave Pública (PEM):\n", publicKeyPem);
