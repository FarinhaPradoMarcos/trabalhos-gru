// Variáveis globais
let isAuthenticated = false;
const reminders = [];

// Função para autenticar por voz
function authenticate() {
    const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = 'pt-BR';
    
    recognition.onstart = () => {
        console.log("Aguardando fala...");
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript.toLowerCase();
        console.log(`Você disse: ${transcript}`);
        
        // Verificar se a frase corresponde
        if (transcript === "minha frase de acesso") { // A frase correta
            isAuthenticated = true;
            document.getElementById("authMessage").innerText = "Acesso concedido!";
            document.querySelector('.password-section').style.display = 'block';
        } else {
            document.getElementById("authMessage").innerText = "Acesso negado! Tente novamente.";
        }
    };

    recognition.onerror = (event) => {
        console.error("Erro no reconhecimento de voz: ", event.error);
        document.getElementById("authMessage").innerText = "Erro ao tentar reconhecer a voz.";
    };

    recognition.start();
}

// Função para adicionar uma senha
function addPassword() {
    const account = document.getElementById("accountInput").value;
    const password = document.getElementById("passwordInput").value;

    if (account && password) {
        reminders.push(`A senha da conta "${account}" foi armazenada.`);
        document.getElementById("addPasswordMessage").innerText = "Senha adicionada com sucesso!";
        document.getElementById("accountInput").value = '';
        document.getElementById("passwordInput").value = '';
    } else {
        document.getElementById("addPasswordMessage").innerText = "Por favor, preencha todos os campos.";
    }
}

// Função para mostrar lembretes
function showReminders() {
    const reminderList = document.getElementById("reminderList");
    reminderList.innerHTML = ''; // Limpar a lista antes de adicionar

    if (reminders.length > 0) {
        reminders.forEach(reminder => {
            const li = document.createElement('li');
            li.textContent = reminder;
            reminderList.appendChild(li);
        });
    } else {
        reminderList.innerHTML = '<li>Nenhum lembrete encontrado.</li>';
    }
}

// Eventos de clique
document.getElementById("authButton").addEventListener("click", authenticate);
document.getElementById("addPasswordButton").addEventListener("click", addPassword);
document.getElementById("reminderButton").addEventListener("click", showReminders);
